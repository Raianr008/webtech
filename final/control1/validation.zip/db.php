<?php
class db{
var $tbname="student";
public function connect()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "webtech";
 //$tbname="student";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db);

 return $conn;
 }



public function savaData($user,$em,$pass) {

  $conn=$this->connect();
  mysqli_query($conn, "insert into ".$this->tbname."(username,email,password) values ('$user','$em','$pass')")or die (mysqli_error($conn));
}
//  function ShowAll($conn,$table)
//  {
// $result = $conn->query("SELECT * FROM  $table");
//  return $result;
//  }


function CloseCon($conn)
 {
 $conn -> close();
 }
}
?>
